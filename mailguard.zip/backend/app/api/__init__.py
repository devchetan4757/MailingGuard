"""
MailGuard API package.
"""
