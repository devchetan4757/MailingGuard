# Sample data

Owner: whoever is building the demo dataset (see master doc, section 10).

Put the wrapped .eml test files here (200-500 from the Kaggle phishing
dataset, plus the 10-15 deliberately-matching pairs for the Case Memory
demo). Keep raw source data out of git if it's large - add a note here on
where teammates can download it instead of committing it.
